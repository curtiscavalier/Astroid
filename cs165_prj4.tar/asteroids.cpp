#include "point.h"     
#include "uiInteract.h" 
#include "uiDraw.h"     
#include <math.h>
#include "Rocks.h"
#include <vector>
using namespace std;

// set the bounds of the game
float Point::xMin = -128.0;
float Point::xMax =  128.0;
float Point::yMin = -128.0;
float Point::yMax =  128.0;

#define NUMBER_OF_BULLETS 5
#define FRAME_COUNT 15
#define deg2rad(value) ((M_PI / 180) * (value))

/*****************************************
* Bullet
* Our bullet class.
****************************************/
class Bullet
{
public:
  Bullet();
  Point point; 
  int x; 
  int y; 
  bool dead;
  bool inScreen;
  void draw();
  
};

/*****************************************
* Bullet: Draw
* Draws a bullet
****************************************/
void Bullet::draw()
{
  if (!dead)
    drawDot(point);
}

/*****************************************
* Asteroid
* The main Asteroid class which has all of the 
* properties used for our game
****************************************/
class Asteroid
{
public:
   Asteroid();
   void reset();
   void advance();
   void draw();   
   void die();
   void triggerEvent(int left, int right, int space, int isUp, int isDown, bool isEnter); 
   void showSaucer();
   int wait; 
   int saucerWait;
   bool saucerDead;
   double saucerDx;
   double saucerDy;
   
private:
   int score;
   int missScore;
   Bullet bullets[NUMBER_OF_BULLETS]; 
   int count;
   bool started;
   int blinkingText;
   bool gameOver;
   Point ship; //location of the ship
   Point saucer; //random saucer
   int shipRotation;
   double shipDx;
   double shipDy;
   int small,medium,large;
   int lives;
   bool dead;
   int initialSaucerX;
   int initialSaucerY;
   vector<Rocks*> rocks; //vector with pointers of asteroids
   
   SmallAsteroid littleAst[NUM_SMALL_ROCKS];
   MediumAsteroid mediumAst[NUM_MED_ROCKS];
   LargeAsteroid largeAst[NUM_BIG_ROCKS];
};



/***************************************************
 * Asteroid:: CONSTRUCTOR
 * Sets everything up
 ***************************************************/
Asteroid::Asteroid() : score(0),missScore(0),small(0),medium(0),large(0)
{
   ship.setX(0);
   ship.setY(0);
   shipRotation = 0;
   lives = 3; 
   dead = false;
   started = false;
   blinkingText = 0;
   gameOver = false;
   wait = 0;
   saucerWait = 0;
   saucerDead = true;
   saucerDx = -1.0;
   saucerDy = 1.0;
   
   for (int i = 0; i < NUM_BIG_ROCKS; i++)
   {
     if (!largeAst[i].dead)
      {
	rocks.push_back(&largeAst[i]);
      }
   }
   
   for(int i = 0; i < NUM_MED_ROCKS; i++)
   {
     mediumAst[i].dead = true;
     rocks.push_back(&mediumAst[i]);
  }
  
   for(int i = 0; i < NUM_SMALL_ROCKS; i++)
   {
     littleAst[i].dead = true;
     rocks.push_back(&littleAst[i]);
  }
};

void Asteroid::showSaucer()
{
  saucer.setX(130);
  saucer.setY(random(-128,128));
  initialSaucerX = saucer.getX();
  initialSaucerY = saucer.getY();
}

void Asteroid::die()
{
  dead = true;                                                
  lives--;
  if (lives != 0)
  {  
    blinkingText = 0;
    ship.setX(0);                     
    ship.setY(0);
    shipDx = 0;			
    shipDy = 0;
    shipRotation = 0;		
  }
  else if (lives == 0)
  {
    started = false;
    gameOver = true;
  }
}

/***************************************************
 * BULLET:: CONSTRUCTOR
 * Sets our bullets up
 ***************************************************/
Bullet::Bullet()
{
     dead = true;
     x = point.getXMax();
     y = point.getYMin();
     inScreen = false;
}

/***************************************************
* Asteroid:: Advance
* Moves everything
***************************************************/
void Asteroid::advance()
{	
  
  //moves ship
   ship.setX(ship.getX() + shipDx);
   ship.setY(ship.getY() + shipDy);

   //moves saucer
   if (!saucerDead)
   {
      saucer.setX(saucer.getX() + saucerDx);
      saucer.setY(saucer.getY() + saucerDy);
      if (saucer.getY() > initialSaucerY + 10)
	saucerDy = -1.0;
      else if (saucer.getY() < initialSaucerY - 10)
	saucerDy = 1.0;
      
      if (saucer.getX() < -128)
      {
         saucerDead = true;
      }
   }
   if ((ship.getX() + shipDx) < ship.getXMin())
      ship.setX(ship.getXMax());
   else if ((ship.getX() + shipDx) > ship.getXMax())
      ship.setX(ship.getXMin());
   else if ((ship.getY() + shipDy) < ship.getYMin())
      ship.setY(ship.getYMax());
   else if ((ship.getY() + shipDy) > ship.getYMax())
      ship.setY(ship.getYMin());
   
   //moves the asteroids from one side of the screen to the other
  for (int i = 0; i < rocks.size(); i++)
  {
    Rocks *rock = (Rocks *)rocks[i]; //pointer to our rock
   if ((rock->point.getX() + rock->dx) < rock->point.getXMin())
      rock->point.setX(rock->point.getXMax());
   else if ((rock->point.getX() + rock->dx) > rock->point.getXMax())
      rock->point.setX(rock->point.getXMin());
   else if ((rock->point.getY() + rock->dy) < rock->point.getYMin())
      rock->point.setY(rock->point.getYMax());
   else if ((rock->point.getY() + rock->dy) > rock->point.getYMax())
      rock->point.setY(rock->point.getYMin());
  }
  
   
    for (int i = 0; i < NUMBER_OF_BULLETS; i++)
    {
      
      if (!bullets[i].dead)
      {

	bullets[i].point.setY(bullets[i].point.getY() + bullets[i].y);
	bullets[i].point.setX(bullets[i].point.getX() + bullets[i].x);
      }

      if(bullets[i].point.getY() > 128 || bullets[i].point.getX() < -128 || bullets[i].point.getY() < -128 || bullets[i].point.getX() > 128)
      {
	bullets[i].dead = true;
	bullets[i].inScreen = false;
      }
     

      if (!saucerDead)
      {
	double distance = sqrt(pow(bullets[i].point.getX() - saucer.getX(),2) + pow(bullets[i].point.getY() - saucer.getY(),2));
	if (distance < 10)
	{
	    saucerDead = true;
	    bullets[i].dead = true; 
	    bullets[i].inScreen = false;
	    score+=5;
	}
      }
      //when they hit
      for (int j = 0; j < rocks.size(); j++)
      {
	Rocks *rock = (Rocks *)rocks[j];
	if (!rock->dead)
	{
	  double distance = sqrt(pow(bullets[i].point.getX() - rock->point.getX(),2) + pow(bullets[i].point.getY() - rock->point.getY(),2));
	  
	  if (distance < rock->radius + 2)
	  {
	    
	    if( bullets[i].dead == false)
	    {
	      
	      bullets[i].dead = true;
	      bullets[i].inScreen = false;
              rock->dead=true; //gets it offscreen
	      //increases the scores
	      if (rock->radius == BIG_ROCK_RADIUS)
		score+=3;
	      else if (rock->radius == MED_ROCK_RADIUS)
		score+=2;
	      else
		score++;
	      
	      rock->kill(rocks); 
	      
	    }
	  }
	}
      }
    }
    
    //saucer-ship collision
    if (!saucerDead)
    {
	double distance = sqrt(pow(ship.getX() - saucer.getX(),2) + pow(ship.getY() - saucer.getY(),2));
	if (distance < 12)
	{
	  saucerDead = true;
	  die();
	}
    }
    
  //advances the asteroids  
  for (int i = 0; i < rocks.size(); i++)
  {
    //Rocks *rock = (Rocks *)rocks[i];
    if(!rocks[i]->dead)
    {
      rocks[i]->point.setX(rocks[i]->point.getX() + rocks[i]->dx);
      rocks[i]->point.setY(rocks[i]->point.getY() + rocks[i]->dy);
    }
    
    // did the ship got hit?
    Rocks *rock = (Rocks *)rocks[i]; 
    double distance = sqrt(pow(ship.getX() - rock->point.getX(),2) + pow(ship.getY() - rock->point.getY(),2));
    if (distance < rock->radius + 4)
    {
      if (!dead && !rock->dead && started)
      {
	rocks[i]->dead = true;
	die();
      }
    }
  }
}

/***************************************************
* Asteroid:: triggerEvent
* Monitors if keyboard keys have been pressed
***************************************************/
void Asteroid::triggerEvent(int left, int right, int space, int isUp, int isDown, bool isEnter)
{
  if (gameOver==false)
  {
    if(isEnter)
    {
      started = true;
    }
    if (started)
    {
      //keeps the ship angle within 360 degrees
      if (shipRotation > 360)
	  shipRotation = 0;
      if (shipRotation < 0)
	  shipRotation = 360;
      
      if (left)
	  shipRotation = shipRotation + (left + 15) / 5;

      if (right)
	shipRotation = shipRotation - (right + 15) / 5;
      
      
      if(isUp)
      {
	  shipDx = ((-cos(deg2rad(shipRotation)) * .2) + shipDx); 
	  shipDy = ((-sin(deg2rad(shipRotation)) * .2) + shipDy);
      }
      
      //space key has been pressed
      if(space && !dead)
      {
	  int thisBullet = -1; //index
	  
	  for(int i = 0; i < NUMBER_OF_BULLETS; i++)
	  {
	    //Take from dead bullets, and offscreen bullets
	    if(bullets[i].dead == true && bullets[i].inScreen == false)
	    {
	      thisBullet = i;
	      bullets[i].dead = false; //revive bullet
	      bullets[i].inScreen = true; //put bullet in screen
	      break;
	    }
	  }
	  
	  if (thisBullet > -1) //available bullet
	  {
	    bullets[thisBullet].point.setX(ship.getX() -5);
	    bullets[thisBullet].point.setY(ship.getY());
	    
	    //put the bullet in top of the gun
	    rotate(bullets[thisBullet].point,ship,shipRotation);
	  
	    drawDot(bullets[thisBullet].point);
	      
	    bullets[thisBullet].x = -cos(deg2rad(shipRotation)) * 5;
	    bullets[thisBullet].y = -sin(deg2rad(shipRotation)) * 5;
	  }
      }

    }
  }
}

/*************************************************
* Asteroid : DRAW
* Draws everything
************************************************/
void Asteroid::draw()
{
  if (started && saucerDead)
  {
     saucerWait++;
  }
  
  if (saucerWait >= 100 && saucerDead)
  {
    saucerWait = 0;
    showSaucer();
    saucerDead=false;
  }
  else if(!saucerDead)
  {
    drawSaucer(saucer);
  }
   // draws the scores
   Point score1(-123, 123);
   drawNumber(score1, score);
  
       
   //Draws bullets
   for (int i = 0; i < NUMBER_OF_BULLETS; i++)
   {
      bullets[i].draw();
   }
   
  int rocksCounter = 0; 
  for (int i = 0; i < rocks.size(); i++)
  {
    if (rocks[i]->dead)
    {
      rocksCounter++;
    }
    rocks[i]->draw();
  }
  
  if (rocksCounter == rocks.size())
  {
    //we have destroyed all the asteroids,
    //restart some big asteroids
     for (int i = 0; i < rocks.size(); i++)
     {
	if (rocks[i]->radius == BIG_ROCK_RADIUS && rocks[i]->dead)
        {
	  //restarts the rocks to random positions
	  rocks[i]->dead = false;
	  
	  if (random(-2,2) == 0)
	    rocks[i]->point.setX(-128);
	  else
	    rocks[i]->point.setX(128);

	  rocks[i]->point.setY(random(-128,128));
	  rocks[i]->dy = (random(-2.0,2.0));
	  if (rocks[i]->point.getX() >= 0)
	    rocks[i]->dx = -2.0;
	  else
	    rocks[i]->dx = 2.0;
	}
    }
  }
  
   //Draws Ship
  if (!dead && started)
    drawShip(ship, shipRotation);
  else if(dead)
  {
    //Ship died :(
    if (wait < 50)
      wait++;
    else
    {
      dead = false; //wait 90 frames then revive the ship
      wait = 0; //reset wait
    }
  }
  else
  if(!started)
  {
    Point title(-50,30);
    drawText(title,"Hello brother Sloan");
    
      if (gameOver)
      {
	Point go(-35,15);
      drawText(go,"GAME OVER");
      }
      
      Point intro(-50,0);
      //Blinking starting text
      if (blinkingText < 10 || blinkingText < 20)
      {
	if (blinkingText < 10)
	{
	  if (!gameOver)
	    drawText(intro,"Press Enter to Start.");
	}
	  blinkingText++;
      }
      else
	blinkingText=0;
      
      
  }
   //keeps graphical score
   Point l[lives];
    for (int i = 0; i < lives; i++)
    {
      l[i].setX(-100 - (6 * i + 1 ));
      l[i].setY(100);
      drawShip(l[i],268);
    }
  
}

/*********************************************
 * CALLBACK
 * The main interaction loop of the engine.
 * This gets called from OpenGL.  It give us our
 * interface pointer (where we get our events from)
 * as well as a void pointer which we know is our
 * game class.
 *********************************************/
void callBack(const Interface *pUI, void *p)
{
   // we know the void pointer is our game class so
   // cast it into the game class.
   Asteroid *pAsteroid = (Asteroid *)p;

   // advances everything
   pAsteroid->advance();


   //Asteroid
   pAsteroid->triggerEvent(pUI->isLeft(), pUI->isRight(),pUI->isSpace(),pUI->isUp(),pUI->isDown(), pUI->isEnter());

   // draw it
   pAsteroid->draw();
}


/*********************************
 * MAIN
 * initialize the drawing window, initialize
 * the game,and run it!
 *********************************/
int main(int argc, char **argv)
{  
   // Start the drawing
   Interface ui(argc, argv, "Asteroids");
   // play the game.  Our function callback will get called periodically
   Asteroid asteroid; 
   ui.run(callBack, (void *)&asteroid);
   return 0;
}
