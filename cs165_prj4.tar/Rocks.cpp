#include <vector>
#include "Rocks.h"

Rocks::Rocks(int r)
{
  radius = r;
  dead = false;
  hit = false;       
  if (random(-2,2) == 0)
    point.setX(-128);
  else
    point.setX(128);
  
  point.setY(random(-128,128));
   dy = (random(-2.0,2.0));
  if (point.getX() >= 0)
    dx = -2.0;//-4.0;
  else
    dx = 2.0;//4.0;
}

Rocks::Rocks(){};

/****************************************
* SmallAsteroid::draw():
* draws a small asteroid 
*****************************************/
void SmallAsteroid::draw() const
{                                           
  if (!dead)                               
     drawCircle(point, SMALL_ROCK_RADIUS, 10, 5);
}

/******************************************
* MediumAsteroid::draw():
* draws a medium asteroid  
*******************************************/
void MediumAsteroid::draw() const
{ 
  if (!dead)                               
     drawCircle(point, MED_ROCK_RADIUS, 5, 10);
}

/******************************************
* LargeAsteroid::draw():
* draws a large asteroid  
*******************************************/
void LargeAsteroid::draw() const
{                 
  if (!dead)                               
     drawCircle(point, BIG_ROCK_RADIUS, 6, 5);
}

void LargeAsteroid::kill(std::vector<Rocks*> &r) const
{
  int medCount=0,smallCount = 0;
  for (int i = 0; i < r.size(); i++)
  {
    if (r[i]->dead)
    {
      if (r[i]->radius == MED_ROCK_RADIUS)
      {
	if (medCount < 2) 
	{
	  
	  r[i]->dead = false;
	  r[i]->point.setX(point.getX()); 
	  r[i]->point.setY(point.getY()); 
	  
	  r[i]->dx = dx; 
	  
	  if (medCount == 1)
	    r[i]->dy = dy + 1;
	  else
	     r[i]->dy = dy - 1;
	     
          medCount ++; 
	}
      }
      else
      {
	if (r[i]->radius == SMALL_ROCK_RADIUS) 
	{
	    if (smallCount < 1)
	    {
	      r[i]->dead = false; 
	      r[i]->dx = dx; 
	      r[i]->dy = dy;
	      
	      r[i]->point.setX(point.getX() + 2);
	      r[i]->point.setY(point.getY());
	      
	      smallCount ++;
	    }
	  }
	}
    }
  }
}

void MediumAsteroid::kill(std::vector<Rocks*> &r) const
{
  int count = 0;
  for (int i = 0; i < r.size(); i++)
  {
    if (r[i]->radius == SMALL_ROCK_RADIUS)
    {
      if (count < 2)
      {
	r[i]->dead = false;
	
	if (count == 1)
	  r[i]->point.setX(point.getX() + 3);
	else
	  r[i]->point.setX(point.getX() - 3);
	
	r[i]->point.setY(point.getY());
	r[i]->dx = dx;
	r[i]->dy = dy;
	
	count++;
      }
    }
  }
}
