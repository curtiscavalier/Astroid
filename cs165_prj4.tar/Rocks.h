#include <vector>
#include "uiInteract.h"  
#include "uiDraw.h"      
#include "point.h"       

#define NUM_BIG_ROCKS 2
#define NUM_MED_ROCKS 4
#define NUM_SMALL_ROCKS 8
#define BIG_ROCK_RADIUS 21
#define MED_ROCK_RADIUS 13
#define SMALL_ROCK_RADIUS 8


class Rocks
{
public:
  Rocks();
  Rocks(int r);
  Point point;
  virtual void draw() const {}; 
  virtual void kill(std::vector<Rocks*> &r) const {}; 
  bool hit;            
  bool dead;           
  float dy;            
  float dx;            
  int radius;
};

class LargeAsteroid: public Rocks
{
public:
  LargeAsteroid(): Rocks(BIG_ROCK_RADIUS) {};
  void draw() const;
  void kill(std::vector<Rocks*> &r) const;
private:
  int radius;
};

class MediumAsteroid: public Rocks
{
public:
  MediumAsteroid(): Rocks(MED_ROCK_RADIUS) {};
  void draw() const;
  void kill(std::vector<Rocks*> &r) const;
private:
  int radius;
};

class SmallAsteroid: public Rocks
{
public:
  SmallAsteroid(): Rocks(SMALL_ROCK_RADIUS){};
  void draw() const;
private:
  int radius;
};
